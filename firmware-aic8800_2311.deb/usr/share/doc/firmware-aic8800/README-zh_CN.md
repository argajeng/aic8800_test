# Linux 下编译、安装 AIC8800 无线网卡芯片的驱动

* v0.1, 2023-10-15, Careone 编写、整理

* v0.2, 2024-04-16, Careone 更新

## 适用的无线网卡型号（示例）

#### 厂商：Tenda (腾达)

1. Tenda (腾达) U2 V5.0 (带单根天线)

   * 设备型号：Tenda U2 V5.0 无线网卡

   * 芯片型号：AIC8800 (爱科微)

   * 上市日期：2023.10 

   * 驱动文件 (共2个)：aic_load_fw.ko, aic8800_fdrv.ko

## 驱动源码来源

* Tenda 官网驱动下载页面

   - https://www.tenda.com.cn/download/cata-10.html

   - https://www.tenda.com.cn/download/detail-3764.html

#### 准备工作

1. 插入 USB 无线网卡。

2. 使用 lsusb 命令查看对应的无线网卡芯片型号信息：

`Bus 001 Device 013: ID a69c:5721 aicsemi Aic MSC`

说明：

* 上面显示的 ID 相关信息， 前面的 a69c 是芯片的厂家代码，即 Aic (爱科微)；

* 后面的 5721 是芯片型号，对应型号 aic8800

 ---
 
 驱动安装成功后，如果再次运行命令 lsusb，则相关信息会变成 "Tenda AIC8800DC"
 
`Bus 001 Device 007: ID 2604:0014 Tenda AIC8800DC`

#### 第 1 步

sudo apt install linux-headers-$(uname -r) build-essential bc

#sudo apt install linux-kbuild-5.10 

#### 第 2 步

## 示例：
##cp -pv aic8800_fdrv.ko /lib/modules/5.10.0-26-amd64/kernel/drivers/net/wireless/

```
sudo mkdir -p /lib/modules/$(uname -r)/kernel/drivers/net/wireless/aic8800

sudo cp -pv aic8800_fdrv.ko /lib/modules/$(uname -r)/kernel/drivers/net/wireless/aic8800
sudo cp -pv aic_load_fw.ko /lib/modules/$(uname -r)/kernel/drivers/net/wireless/aic8800
```

## 或者

```
sudo install -p -m 644 aic8800_fdrv.ko /lib/modules/$(uname -r)/kernel/drivers/net/wireless/aic8800/aic8800_fdrv.ko
sudo install -p -m 644 aic_load_fw.ko /lib/modules/$(uname -r)/kernel/drivers/net/wireless/aic8800/aic_load_fw.ko
```

#### 第 3 步

sudo depmod -a $(uname -r)

#### 第 4 步

sudo modprobe -v aic8800_fdrv

提示：运行完这一步，屏幕右上角（或者右下角）通常就会弹出 WiFi 信号提示。

说明驱动安装成功。选择一个 WiFi 信号，输入密码，就可以上网了。


#### 第 5 步 [可选操作]

在 aic8800 芯片的无线网卡的驱动没有正常安装前，某些较早版本的系统
 （如 Debian 10.13), 或者较老的电脑主板，可能会把这个插入的 USB 无线网卡，
  当作一个普通的 U 盘 /dev/sdb (或者 U 盘分区 /dev/sdb1) ！
      (U 盘的内容，实际上包含这个网卡芯片的几个 Windows 驱动程序文件
  Setup.EXE, 以及其它文件。)
 
 以 root 用户身份，或者 sudo, 运行下面的命令来 卸载、弹出 U 盘:

```
sudo umount /dev/sdb1
sudo eject /dev/sdb
```


#### 其它技术信息

* 测试环境：Debian 11.9 amd64, 内核 5.10.0-28-amd64

* 测试日期：2024-04-16

`lsusb | grep -i Aic`

`Bus 001 Device 013: ID a69c:5721 aicsemi Aic MSC`

---

/lib/modules/5.10.0-28-amd64/kernel/drivers/net/wireless/aic8800/aic8800_fdrv.ko 

/lib/modules/5.10.0-28-amd64/kernel/drivers/net/wireless/aic8800/aic_load_fw.ko

